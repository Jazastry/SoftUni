<?php
    if (isset($_POST['submit'])) {

        $firstName = $_POST["firstName"];
        $lastName = $_POST["lastName"];
        $email = $_POST["email"];
        $telephone = $_POST["telephone"];
        $comment = $_POST["comment"];
        $birthDate = $_POST["birthDate"];
        $nationality = $_POST["nationality"];
        $lastWorkName = $_POST["lastWorkName"];
        $lastWorkFromDate = $_POST["lastWorkFromDate"];
        $lastWorkToDate = $_POST["lastWorkToDate"];
        $programLanguages = $_POST["programLanguages"];
        $progLangLevel = $_POST["progLangLevel"];
        $languages = $_POST["languages"];
        $languageComprehension = $_POST["languageComprehension"];
        $languageReadingSkills = $_POST["languageReadingSkills"];
        $languageWritingSkills = $_POST["languageWritingSkills"];
        $driverLicense = $_POST["driverLicense"];
        $languageWritingSkills = $_POST["languageWritingSkills"];
    }

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>

