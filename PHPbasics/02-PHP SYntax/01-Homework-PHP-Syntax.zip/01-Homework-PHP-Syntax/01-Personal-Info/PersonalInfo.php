<?php
$firstName = "Pesho";
$lastName = "Peshev";
$age = 55;

$fullName = $firstName . ' '  . $lastName;
$result = "My name is " . $fullName . " and I am " . $age .  " years old.";
echo ($result);
?>		
